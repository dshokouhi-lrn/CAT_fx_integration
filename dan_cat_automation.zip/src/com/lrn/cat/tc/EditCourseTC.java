package com.lrn.cat.tc;

import org.testng.annotations.Test;

import com.lrn.cat.page.EditCourse;

public class EditCourseTC extends EditCourse{
	@Test
	void CATeditTC () throws Exception
	{
		editcourse();
	}

}
