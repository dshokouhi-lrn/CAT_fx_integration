package com.lrn.cat.page;

import com.lrn.cat.common.CATAppCommon;
import com.lrn.pp.utility.Log;

public class LogoutPage extends CATAppCommon{
	
	
	static public void logout() throws Exception
    {
           try
           {
                  Log.startTestCase("Verify CAT Logout ");
                  clickIdentifierXpath("//a");
                  clickIdentifierXpath("//li[8]/a/span");
                 
                  Thread.sleep(300);
                  //     Assert.assertTrue(waitForElementPresentByLinkText("log out"));
                  Log.pass("Logged-out Successfully!!");

           }
           catch(Exception e){  
                  Log.fail("Failed to logout of Application");
                  e.printStackTrace();
                  throw e;                                        
           } catch(AssertionError e)
           {
                  Log.fail("Failed to logout of Application");
                  e.printStackTrace();
                  throw e;

           }
    }
}

	
	


