package com.lrn.cat.page;

import java.util.Date;

import com.lrn.cat.common.CATAppCommon;
import com.lrn.pp.utility.Log;

public class AddTopic extends CATAppCommon {
	
	static public void addTopic(String topicName) throws Exception
	{
		try {
			
		
			Date d = new Date();
			
			Log.startTestCase("start adding topic");
			
			clickIdentifierXpath("//*[@id='courseTreeOperationIcons']/li[2]");
			
			Thread.sleep(300);
			
			typeTextByXpath("//*[@id='note_pag']/ul/li/input", topicName + " " + d.toString());
			
			clickIdentifierXpath("//body/div[12]/div[3]/div/button[1]");
			
			Log.info("topic created");
		}
		
		catch(Exception e){  
		       Log.fail("Failed to add topic");
		       e.printStackTrace();
		       throw e;                                        
		} catch(AssertionError e)
		{
		       Log.fail("Failed to add topic");
		       e.printStackTrace();
		       throw e;

		}
	}

}
