package com.lrn.cat.page;


import com.lrn.cat.common.CATAppCommon;
import com.lrn.pp.utility.Log;

public class AddPage extends CATAppCommon {

	static public void addPage(String template) throws Exception
	{
		try {
		
			Log.startTestCase("adding a " + template + " page");
			
			if (template == "consult")
				template = "0-0";
			
			if (template == "text")
				template = "0-1";
			
			if (template == "consent")
				template = "0-2";
			
			if (template == "hotspot")
				template = "0-3";
			
			if (template == "binary")
				template = "0-4";
			
			if (template == "sidebar")
				template = "1-0";
			
			if (template == "dnd")
				template = "1-1";
			
			if (template == "saq")
				template = "1-2";
			
			if (template == "carousel")
				template = "1-3";
			
			if (template == "video")
				template = "1-4";
			
			if (template == "snr")
				template = "2-0";
			
			if (template == "concern")
				template = "2-1";
			
			if (template == "multiple")
				template = "2-2";
			
			
			clickIdentifierXpath("//*[@id='courseTreeOperationIcons']/li[3]");
			
			Thread.sleep(300);
			
			clickIdentifierXpath("//*[@id='template-row-column-image-" + template + "']/img");
			
			Log.info("selected the " + template + " template");
			
			clickIdentifierXpath("//body/div[12]/div[3]/div/button[1]");
			
			Log.info("page added");

		}
		
		catch(Exception e){  
		       Log.fail("Failed to add page");
		       e.printStackTrace();
		       throw e;                                        
		} catch(AssertionError e)
		{
		       Log.fail("Failed to add page");
		       e.printStackTrace();
		       throw e;

		}
		
	}
}
