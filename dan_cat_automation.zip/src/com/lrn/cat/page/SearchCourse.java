package com.lrn.cat.page;

import com.lrn.cat.common.CATAppCommon;
import com.lrn.pp.utility.Log;

public class SearchCourse extends CATAppCommon{
	
	
	static public void searchcourse(String courseName, String courseContent, String courseType) throws Exception
    {
           try
           {
                  Log.startTestCase("Verify Search course ");
                  typeTextById("courseName", courseName);
                  
                  if (courseContent != "")
                	  selectDropdownValueVisibleText("courseContent", courseContent);
                  
                  if (courseType != "")
                  	selectDropdownValueVisibleText("courseType", courseType);
                  
                  Thread.sleep(300);
                  clickIdentifierXpath("//form/div/div/div/input");
                 
                  Thread.sleep(300);
                  //     Assert.assertTrue(waitForElementPresentByLinkText("log out"));
                  Log.pass("Searched course Successfully!!");

           }
           catch(Exception e){  
                  Log.fail("Failed to serach course");
                  e.printStackTrace();
                  throw e;                                        
           } catch(AssertionError e)
           {
                  Log.fail("Failed to serach course");
                  e.printStackTrace();
                  throw e;

           }
    }
}